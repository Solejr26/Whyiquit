'use strict';
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let me = null, cfg = { rx: [], reasons: [], rate: {} }, state = { reason: 'All', q: '', sort: 'new', offset: 0 };
const viewed = new Set();

// ---------- helpers
async function api(path, opts = {}) {
  const o = { method: opts.method || 'GET', headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' };
  if (opts.body !== undefined) { o.method = opts.method || 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
  let r; try { r = await fetch(path, o); } catch { throw new Error('No connection. Check your network.'); }
  let d = {}; try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Something went wrong'); e.status = r.status; throw e; }
  return d;
}
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
function ago(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'just now'; if (d < 3600) return Math.floor(d / 60) + 'm ago'; if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  if (d < 2592000) return Math.floor(d / 86400) + 'd ago'; return Math.floor(d / 2592000) + 'mo ago';
}
const num = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(n));

// ---------- theme
$('#themeBtn').onclick = () => {
  const t = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', t); try { localStorage.setItem('theme', t); } catch {}
};

// ---------- network indicator
function setNet(level, ms) {
  const el = $('#net'); el.className = 'net ' + level;
  $('#netTxt').textContent = { good: 'Good network', fair: 'Slow network', bad: 'Bad network', off: 'Offline' }[level];
  el.title = ms ? `Response time: ${ms} ms` : 'No connection';
  $('#offBanner').classList.toggle('hidden', level !== 'off');
}
async function netCheck() {
  if (document.hidden) return;
  if (!navigator.onLine) return setNet('off');
  const t0 = performance.now(), ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 5000);
  try {
    await fetch('/healthz?' + Date.now(), { cache: 'no-store', signal: ctl.signal }); clearTimeout(to);
    const ms = Math.round(performance.now() - t0), c = navigator.connection;
    const slow = c && /(^|-)2g$/.test(c.effectiveType || '');
    setNet(ms > 1500 || slow ? 'bad' : ms > 600 ? 'fair' : 'good', ms);
  } catch { clearTimeout(to); setNet(navigator.onLine ? 'bad' : 'off'); }
}
addEventListener('online', netCheck); addEventListener('offline', () => setNet('off'));
setInterval(netCheck, 8000); document.addEventListener('visibilitychange', netCheck);

// ---------- rendering
function postHTML(p) {
  const who = p.author ? `<span class="who">${esc(p.author.name)}</span>` : '<span>Anonymous</span>';
  const yrs = p.years ? `${p.years} yr${p.years === 1 ? '' : 's'} there` : '';
  const meta = [p.role && esc(p.role), yrs].filter(Boolean).join(' · ');
  const co = p.company ? `<button class="co" data-co="${esc(p.company)}">${esc(p.company)}</button>` : '';
  const rx = cfg.rx.map((e) => `<button class="rx ${p.my === e ? 'on' : ''}" data-act="rx" data-e="${e}" aria-label="React ${e}">${e}<b>${p.rx[e] || ''}</b></button>`).join('');
  return `<article class="card ${p.pending ? 'pend' : ''}" data-id="${p.id}">
    <div class="meta">${who}<span class="reason">${esc(p.reason)}</span>${meta ? `<span>${meta}</span>` : ''}${co}<span>${ago(p.createdAt)}</span></div>
    ${p.pending ? '<div class="note">Under review. Only you can see this until it is approved.</div>' : ''}
    <p class="story">${esc(p.story)}</p>
    <div class="rxbar">${rx}</div>
    <div class="actions">
      <span title="Views">👁 <b data-v>${num(p.views)}</b></span>
      <button class="link" data-act="cm">💬 <b data-c>${p.comments}</b> comments</button>
      <button class="link" data-act="report">Report</button>
      ${p.mine ? '<button class="link" data-act="del">Delete</button>' : ''}
    </div>
    <div class="cm hidden"></div>
  </article>`;
}
let io;
function observe() {
  if (!('IntersectionObserver' in window)) return;
  io = io || new IntersectionObserver((es) => es.forEach((e) => {
    const id = e.target.dataset.id;
    if (e.isIntersecting && !viewed.has(id)) {
      e.target._t = setTimeout(() => { if (viewed.has(id)) return; viewed.add(id); api(`/api/posts/${id}/view`, { method: 'POST', body: {} }).catch(() => {}); }, 1200);
    } else clearTimeout(e.target._t);
  }), { threshold: 0.6 });
  document.querySelectorAll('#list .card, #coResult .card').forEach((c) => io.observe(c));
}
async function loadPosts(append) {
  if (!append) state.offset = 0;
  const d = await api('/api/posts?' + new URLSearchParams({ reason: state.reason, q: state.q, sort: state.sort, offset: state.offset }));
  const html = d.posts.map(postHTML).join('');
  $('#list').innerHTML = append ? $('#list').innerHTML + html : html || '<div class="empty">No stories here yet. Be the first to share one.</div>';
  $('#more').classList.toggle('hidden', !d.more); state.offset += d.posts.length; $('#newPill').classList.add('hidden'); observe();
}
function renderChips() {
  $('#chips').innerHTML = ['All', ...cfg.reasons].map((r) => `<button class="chip ${r === state.reason ? 'on' : ''}" data-r="${esc(r)}">${esc(r)}</button>`).join('');
}
function bars(list, total) {
  if (!list.length) return '<div class="empty">Nothing yet.</div>';
  const max = Math.max(...list.map((x) => x.count));
  return list.map((x) => `<div class="bar"><div class="lbl"><span>${esc(x.reason)}</span><span>${x.count} (${Math.round(x.count / total * 100)}%)</span></div>
    <div class="track"><div class="fill" data-w="${x.count / max * 100}"></div></div></div>`).join('');
}
const fillBars = () => document.querySelectorAll('.fill[data-w]').forEach((f) => { f.style.width = f.dataset.w + '%'; });
async function loadTrends() { const s = await api('/api/stats'); $('#totalNum').textContent = s.total; $('#trendBars').innerHTML = bars(s.reasons, s.total); fillBars(); }
async function lookupCompany(name) {
  if (!name.trim()) return; const c = await api('/api/company?name=' + encodeURIComponent(name));
  if (!c.total) { $('#coResult').innerHTML = `<div class="empty">No stories about “${esc(name)}” yet.</div>`; return; }
  $('#coResult').innerHTML = `<div class="card"><div class="big">${c.total}</div><div class="meta">${c.total === 1 ? 'story' : 'stories'} about ${esc(c.company)}. People stayed about ${c.avgYears} years on average.</div>${bars(c.reasons, c.total)}
    <div class="note">Anonymous, unverified opinions. Not facts about the company.</div></div>` + c.posts.map(postHTML).join('');
  fillBars(); observe();
}
function showTab(t) {
  document.querySelectorAll('.tab[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
  ['feed', 'trends', 'company'].forEach((id) => $('#' + id).classList.toggle('hidden', id !== t));
  if (t === 'trends') loadTrends().catch((e) => toast(e.message)); scrollTo(0, 0);
}

// ---------- comments
async function loadComments(card) {
  const box = card.querySelector('.cm'), id = card.dataset.id;
  const d = await api(`/api/posts/${id}/comments`);
  box.innerHTML = d.comments.map((c) => `<div class="cmt" data-cid="${c.id}"><b>${esc(c.author.name)}</b> <small>${ago(c.createdAt)}</small>${c.pending ? ' <small>(under review)</small>' : ''}<br>${esc(c.text)}
    <button class="link" data-act="creport">Report</button>${c.mine ? '<button class="link" data-act="cdel">Delete</button>' : ''}</div>`).join('') +
    `<form class="row" data-act="cform"><input maxlength="500" placeholder="${me ? 'Write a comment…' : 'Sign in to comment'}" ${me ? '' : 'disabled'}><button class="btn sm" ${me ? '' : 'disabled'}>Send</button></form>`;
}

// ---------- events
document.addEventListener('click', async (e) => {
  const tab = e.target.closest('.tab[data-tab]'); if (tab) return showTab(tab.dataset.tab);
  const chip = e.target.closest('.chip'); if (chip) { state.reason = chip.dataset.r; renderChips(); return loadPosts().catch((x) => toast(x.message)); }
  const co = e.target.closest('.co'); if (co) { showTab('company'); $('#coName').value = co.dataset.co; return lookupCompany(co.dataset.co); }
  const b = e.target.closest('[data-act]'); if (!b || b.tagName === 'FORM') return;
  const card = b.closest('.card'), id = card && card.dataset.id;
  try {
    if (b.dataset.act === 'rx') {
      if (!me) return openAuth('login');
      const em = b.dataset.e, my = card.querySelector('.rx.on'); b.classList.add('pop');
      const d = await api(`/api/posts/${id}/react`, { method: 'POST', body: { emoji: my === b ? null : em } }); paintRx(id, d.rx, d.my);
    } else if (b.dataset.act === 'cm') {
      const box = card.querySelector('.cm'); box.classList.toggle('hidden'); if (!box.classList.contains('hidden')) await loadComments(card);
    } else if (b.dataset.act === 'report') {
      if (!me) return openAuth('login'); if (!confirm('Report this story to the moderators?')) return;
      await api(`/api/posts/${id}/report`, { method: 'POST', body: {} }); toast('Thanks, we will review it.');
    } else if (b.dataset.act === 'del') {
      if (!confirm('Delete your story permanently?')) return; await api(`/api/posts/${id}/delete`, { method: 'POST', body: {} }); card.remove();
    } else if (b.dataset.act === 'creport' || b.dataset.act === 'cdel') {
      const cid = b.closest('.cmt').dataset.cid; if (b.dataset.act === 'cdel' && !confirm('Delete this comment?')) return;
      await api(`/api/comments/${cid}/${b.dataset.act === 'cdel' ? 'delete' : 'report'}`, { method: 'POST', body: {} });
      toast(b.dataset.act === 'cdel' ? 'Deleted.' : 'Reported. Thanks.'); await loadComments(card);
    }
  } catch (err) { toast(err.message); if (err.status === 401) { me = null; renderAcct(); } }
});
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('form[data-act=cform]'); if (!f) return; e.preventDefault();
  const inp = f.querySelector('input'), card = f.closest('.card'); if (!inp.value.trim()) return;
  try { const d = await api(`/api/posts/${card.dataset.id}/comments`, { method: 'POST', body: { text: inp.value } });
    if (d.pending) toast('Your comment is under review.'); await loadComments(card); } catch (err) { toast(err.message); }
});
function paintRx(id, rx, my) {
  const card = document.querySelector(`[data-id="${id}"]`); if (!card) return;
  card.querySelectorAll('.rx').forEach((b) => { const n = rx[b.dataset.e] || 0; b.querySelector('b').textContent = n || ''; if (my !== undefined) b.classList.toggle('on', my === b.dataset.e); setTimeout(() => b.classList.remove('pop'), 400); });
}
let qt; $('#q').addEventListener('input', (e) => { clearTimeout(qt); qt = setTimeout(() => { state.q = e.target.value; loadPosts().catch(() => {}); }, 300); });
$('#sort').addEventListener('change', (e) => { state.sort = e.target.value; loadPosts(); });
$('#more').onclick = () => loadPosts(true);
$('#newPill').onclick = () => loadPosts();
$('#coGo').onclick = () => lookupCompany($('#coName').value);
$('#coName').addEventListener('keydown', (e) => { if (e.key === 'Enter') lookupCompany(e.target.value); });

// ---------- live updates (Server-Sent Events)
function live() {
  if (!('EventSource' in window)) return;
  const es = new EventSource('/api/stream');
  es.onmessage = (m) => {
    let ev; try { ev = JSON.parse(m.data); } catch { return; }
    const card = document.querySelector(`[data-id="${ev.id}"]`);
    if (ev.t === 'rx') paintRx(ev.id, ev.rx);
    if (ev.t === 'views' && card) card.querySelector('[data-v]').textContent = num(ev.n);
    if (ev.t === 'comments' && card) { card.querySelector('[data-c]').textContent = ev.n; const box = card.querySelector('.cm'); if (!box.classList.contains('hidden') && !box.querySelector('input:focus')) loadComments(card).catch(() => {}); }
    if (ev.t === 'gone' && card && !(card.classList.contains('pend'))) card.remove();
    if (ev.t === 'post' && !$('#feed').classList.contains('hidden')) $('#newPill').classList.remove('hidden');
  };
}

// ---------- accounts
function renderAcct() {
  const b = $('#acctBtn'); b.textContent = me ? me.name : 'Sign in';
  b.onclick = () => (me ? (confirm('Sign out of ' + me.name + '?') && logout()) : openAuth('login'));
}
const authDlg = $('#authDlg');
function openAuth(view, ctx = {}) {
  const forms = {
    login: `<h2>Sign in</h2><form data-f="login"><label>Email or phone</label><input name="identifier" autocomplete="username" placeholder="you@email.com or +234…" required>
      <label>Password</label><input name="password" type="password" autocomplete="current-password" required><div class="err"></div>
      <div class="row"><button class="btn f1">Sign in</button></div></form>
      <div class="row"><button class="link" data-go="register">Create account</button><button class="link" data-go="forgot">Forgot password?</button><button class="link" data-go="close">Close</button></div>`,
    register: `<h2>Create account</h2><form data-f="register"><label>Username (public)</label><input name="name" autocomplete="username" maxlength="20" required>
      <label>Email or phone (with country code)</label><input name="identifier" autocomplete="email" placeholder="you@email.com or +234…" required>
      <label>Password (8+ characters, letters and a number)</label><input name="password" type="password" autocomplete="new-password" required>
      <label class="inl"><input type="checkbox" name="agree" required> I agree to the <a href="/terms.html" target="_blank" rel="noopener">Terms</a> and <a href="/guidelines.html" target="_blank" rel="noopener">Community Guidelines</a></label>
      <div class="err"></div><div class="row"><button class="btn f1">Send confirmation code</button></div></form>
      <div class="row"><button class="link" data-go="login">I already have an account</button><button class="link" data-go="close">Close</button></div>`,
    verify: `<h2>Confirm your ${ctx.identifier && ctx.identifier.includes('@') ? 'email' : 'phone'}</h2><p class="note">Enter the 6-digit code sent to ${esc(ctx.identifier || '')}.${ctx.devCode ? ` <b>Dev code: ${esc(ctx.devCode)}</b>` : ''}</p>
      <form data-f="verify"><input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="123456" required><div class="err"></div>
      <div class="row"><button class="btn f1">Confirm</button></div></form><div class="row"><button class="link" data-go="resend">Resend code</button><button class="link" data-go="close">Close</button></div>`,
    forgot: `<h2>Reset password</h2><form data-f="forgot"><label>Email or phone</label><input name="identifier" required><div class="err"></div><div class="row"><button class="btn f1">Send code</button></div></form><div class="row"><button class="link" data-go="login">Back</button></div>`,
    reset: `<h2>New password</h2><p class="note">Enter the code sent to ${esc(ctx.identifier || '')} and your new password.</p><form data-f="reset"><input name="code" inputmode="numeric" maxlength="6" placeholder="Code" required>
      <label>New password</label><input name="password" type="password" autocomplete="new-password" required><div class="err"></div><div class="row"><button class="btn f1">Save password</button></div></form>`,
  };
  authDlg.ctx = ctx; $('#authBody').innerHTML = forms[view]; authDlg.dataset.view = view;
  if (!authDlg.open) authDlg.showModal();
}
authDlg.addEventListener('click', async (e) => {
  const g = e.target.closest('[data-go]'); if (!g) return; const go = g.dataset.go, c = authDlg.ctx || {};
  if (go === 'close') return authDlg.close();
  if (go === 'resend') { try { await api('/api/auth/resend', { body: { identifier: c.identifier } }); toast('If the account exists, a new code was sent.'); } catch (x) { toast(x.message); } return; }
  openAuth(go);
});
authDlg.addEventListener('submit', async (e) => {
  e.preventDefault(); const f = e.target, kind = f.dataset.f, fd = Object.fromEntries(new FormData(f)), err = f.querySelector('.err'), btn = f.querySelector('button');
  err.textContent = ''; btn.disabled = true; const c = authDlg.ctx || {};
  try {
    if (kind === 'register') { fd.agree = !!fd.agree; const d = await api('/api/auth/register', { body: fd }); openAuth('verify', { identifier: fd.identifier, devCode: d.devCode }); }
    else if (kind === 'login') {
      const d = await api('/api/auth/login', { body: fd });
      if (d.needVerify) openAuth('verify', { identifier: d.identifier, devCode: d.devCode }); else { me = d.me; done('Welcome back!'); }
    } else if (kind === 'verify') { const d = await api('/api/auth/verify', { body: { identifier: c.identifier, code: fd.code } }); me = d.me; done('Account confirmed. Welcome!'); }
    else if (kind === 'forgot') { const d = await api('/api/auth/forgot', { body: fd }); openAuth('reset', { identifier: fd.identifier, devCode: d.devCode }); if (d.devCode) toast('Dev code: ' + d.devCode); }
    else if (kind === 'reset') { await api('/api/auth/reset', { body: { identifier: c.identifier, code: fd.code, password: fd.password } }); toast('Password updated. Sign in.'); openAuth('login'); }
  } catch (x) { err.textContent = x.message; }
  btn.disabled = false;
});
function done(msg) { authDlg.close(); renderAcct(); toast(msg); loadPosts() }
async function logout() { await api('/api/auth/logout', { method: 'POST', body: {} }).catch(() => {}); me = null; renderAcct(); toast('Signed out.'); loadPosts(); }

// ---------- new story
const postDlg = $('#postDlg');
$('#newBtn').onclick = () => (me ? postDlg.showModal() : openAuth('login'));
$('#postCancel').onclick = () => postDlg.close();
$('#postForm').addEventListener('submit', async (e) => {
  e.preventDefault(); const btn = $('#postSubmit'); btn.disabled = true; $('#postErr').textContent = '';
  try {
    const d = await api('/api/posts', { body: { reason: $('#fReason').value, story: $('#fStory').value, role: $('#fRole').value, years: $('#fYears').value, company: $('#fCompany').value, anonymous: $('#fAnon').checked } });
    postDlg.close(); ['#fStory', '#fRole', '#fCompany'].forEach((s) => { $(s).value = ''; }); toast(d.note || 'Posted!');
    state = { reason: 'All', q: '', sort: 'new', offset: 0 }; $('#q').value = ''; $('#sort').value = 'new'; renderChips(); showTab('feed'); loadPosts();
  } catch (x) { $('#postErr').textContent = x.message; }
  btn.disabled = false;
});

// ---------- start
(async () => {
  try {
    cfg = await api('/api/config'); me = (await api('/api/me')).me;
    $('#fReason').innerHTML = cfg.reasons.map((r) => `<option>${esc(r)}</option>`).join('');
    renderAcct(); renderChips(); await loadPosts(); live(); netCheck();
  } catch (e) { toast(e.message); }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
})();
