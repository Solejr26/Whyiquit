'use strict';
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let tab = 'overview', sub = 'pending';
async function call(path, body) {
  const o = { headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' };
  if (body !== undefined) { o.method = 'POST'; o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  const r = await fetch(path, o), d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(d.error || 'Error'); e.status = r.status; throw e; } return d;
}
async function boot() {
  const d = await call('/api/me');
  const ok = d.me && d.me.role === 'admin';
  $('#login').classList.toggle('hidden', ok); $('#panel').classList.toggle('hidden', !ok); $('#out').classList.toggle('hidden', !ok);
  if (ok) render();
}
$('#go').onclick = async () => {
  $('#err').textContent = '';
  try { const d = await call('/api/auth/login', { identifier: $('#id').value, password: $('#pw').value }); if (!d.me || d.me.role !== 'admin') { await call('/api/auth/logout', {}); throw new Error('Not an admin account.'); } $('#pw').value = ''; boot(); }
  catch (e) { $('#err').textContent = e.message; }
};
$('#out').onclick = async () => { await call('/api/auth/logout', {}); boot(); };
$('#tabs').onclick = (e) => { const b = e.target.closest('.chip'); if (!b) return; tab = b.dataset.t; sub = tab === 'users' ? '' : 'pending';
  document.querySelectorAll('#tabs .chip').forEach((c) => c.classList.toggle('on', c === b)); render(); };

const seg = (opts) => `<div class="seg">${opts.map((o) => `<button class="tab ${o === sub ? 'on' : ''}" data-s="${o}">${o}</button>`).join('')}</div>`;
async function render() {
  const v = $('#view');
  try {
    if (tab === 'overview') {
      const o = await call('/api/admin/overview');
      v.innerHTML = `<div class="grid">${[['Users', o.users], ['Stories', o.posts], ['Needs review', o.pending], ['Reported', o.flagged], ['Hidden', o.hidden], ['Live viewers', o.online]].map(([k, n]) => `<div class="card"><div class="meta">${k}</div><div class="big">${n}</div></div>`).join('')}</div>
        <p class="note">AI moderation: <b>${o.ai ? 'on' : 'off (set ANTHROPIC_API_KEY)'}</b></p>`;
    } else if (tab === 'posts' || tab === 'comments') {
      if (!sub) sub = 'pending';
      const d = await call(`/api/admin/${tab}?filter=${sub}`);
      v.innerHTML = seg(['pending', 'flagged', 'hidden', 'all'].filter((x) => tab === 'posts' || x !== 'all')) + (d.items.length ? d.items.map((p) => `<div class="card" data-id="${p.id}">
        <div class="meta">${p.status === 'hidden' ? '<span class="badge hid">hidden</span>' : p.status === 'pending' ? '<span class="badge pen">pending</span>' : ''}${p.reports ? `<span class="badge rep">${p.reports} report${p.reports > 1 ? 's' : ''}</span>` : ''}
        <span>by ${esc(p.author)}</span>${p.reason ? `<span>${esc(p.reason)}</span>` : ''}${p.company ? `<span>${esc(p.company)}</span>` : ''}<span>${new Date(p.at).toLocaleString()}</span></div>
        ${p.note ? `<div class="note">Flag: ${esc(p.note)}</div>` : ''}<p class="story">${esc(p.text)}</p>
        <div class="row">${p.status !== 'live' ? '<button class="btn sm" data-a="approve">Approve</button>' : '<button class="btn ghost sm" data-a="hide">Hide</button>'}
        ${tab === 'posts' && p.reports ? '<button class="btn ghost sm" data-a="dismiss">Dismiss reports</button>' : ''}<button class="btn bad sm" data-a="delete">Delete</button>
        ${p.authorId ? `<button class="btn ghost sm" data-u="${p.authorId}" data-a="ban">Ban author</button>` : ''}</div></div>`).join('') : '<div class="empty">All clear.</div>');
    } else if (tab === 'users') {
      const d = await call('/api/admin/users?q=' + encodeURIComponent(sub || ''));
      v.innerHTML = `<div class="row"><input id="uq" placeholder="Search name, email, phone" value="${esc(sub || '')}"><button class="btn" id="ugo">Search</button></div>` + d.items.map((u) => `<div class="card" data-uid="${u.id}">
        <div class="meta"><b>${esc(u.name)}</b>${u.role === 'admin' ? '<span class="badge">admin</span>' : ''}${u.banned ? '<span class="badge ban">banned</span>' : ''}${u.verified ? '' : '<span class="badge pen">unconfirmed</span>'}<span>${esc(u.contact || '')}</span></div>
        <div class="row">${u.role === 'admin' ? '' : `<button class="btn ghost sm" data-ua="${u.banned ? 'unban' : 'ban'}">${u.banned ? 'Unban' : 'Ban'}</button>`}</div></div>`).join('');
      $('#ugo').onclick = () => { sub = $('#uq').value; render(); };
    } else {
      v.innerHTML = `<div class="card"><b>AI assistant</b><p class="note">Ask for a summary of the review queue, whether a story breaks the guidelines, or how to handle a situation. It advises; you decide.</p>
        <div class="chat" id="chat"></div><textarea id="aiq" maxlength="800" placeholder="e.g. Summarise what needs review and what you'd approve or hide."></textarea>
        <div class="row"><button class="btn f1" id="aiGo">Ask</button></div></div>`;
      $('#aiGo').onclick = async () => { const q = $('#aiq').value.trim(); if (!q) return; $('#aiGo').disabled = true; $('#chat').textContent = 'Thinking…';
        try { const d = await call('/api/admin/ai', { message: q }); $('#chat').textContent = d.reply; } catch (e) { $('#chat').textContent = e.message; } $('#aiGo').disabled = false; };
    }
  } catch (e) { if (e.status === 404 || e.status === 401) boot(); else v.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
}
$('#view').addEventListener('click', async (e) => {
  const s = e.target.closest('[data-s]'); if (s) { sub = s.dataset.s; return render(); }
  const b = e.target.closest('[data-a]'), card = e.target.closest('.card');
  try {
    if (b && card && card.dataset.id) {
      if (b.dataset.a === 'delete' && !confirm('Delete permanently?')) return;
      if (b.dataset.a === 'ban') { if (!confirm('Ban this author and sign them out?')) return; await call(`/api/admin/users/${b.dataset.u}/ban`, {}); }
      else await call(`/api/admin/${tab}/${card.dataset.id}/${b.dataset.a}`, {});
      render();
    }
    const u = e.target.closest('[data-ua]'); if (u) { await call(`/api/admin/users/${card.dataset.uid}/${u.dataset.ua}`, {}); render(); }
  } catch (err) { alert(err.message); }
});
boot();
