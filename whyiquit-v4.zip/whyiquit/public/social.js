'use strict';
const av = (u, sz = '') => `<span class="avw ${sz}">${u.av ? `<img class="av" src="/api/media/${u.av}" alt="">` : `<span class="av">${esc((u.name || '?')[0]).toUpperCase()}</span>`}${u.on ? '<i class="onl" title="Online"></i>' : ''}</span>`;
const post = (path, body = {}) => api(path, { method: 'POST', body });
async function up(file, avatar) {
  const r = await fetch('/api/upload' + (avatar ? '?avatar=1' : ''), { method: 'POST', credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch', 'Content-Type': file.type }, body: file });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || 'Upload failed'); return d.id;
}
// ---- richer story cards
const _p = postHTML;
postHTML = (p) => {
  let h = _p(p); const a = p.author;
  if (a) h = h.replace('<div class="meta">', '<div class="meta">' + av(a));
  if (p.via) h = h.replace('<p class="story">', `<div class="note">🔁 Reshared from ${esc(p.via)}</div><p class="story">`);
  const ex = `<button class="link" data-s="save">${p.saved ? '🔖 Saved' : '🔖 Save'}</button><button class="link" data-s="share">↗ Share</button><button class="link" data-s="reshare">🔁 Reshare${p.shares ? ' · ' + p.shares : ''}</button>` +
    (a && !p.mine ? `<button class="link" data-s="follow" data-u="${a.id}">${p.following ? 'Unfollow' : 'Follow'}</button><button class="link" data-s="dm" data-u="${a.id}">✉ Message</button><button class="link" data-s="mute" data-u="${a.id}">Mute</button><button class="link" data-s="block" data-u="${a.id}">Block</button>` : '');
  return h.replace('<div class="cm hidden">', `<div class="actions">${ex}</div><div class="cm hidden">`);
};
document.querySelector('.tabs').insertAdjacentHTML('beforeend', '<button class="tab" data-tab="chat">Messages</button><button class="tab" data-tab="dash">Dashboard</button>');
$('#company').insertAdjacentHTML('afterend', '<section id="chat" class="hidden"></section><section id="dash" class="hidden"></section>');
let thr = null, keep = false;
const _st = showTab;
showTab = (t) => {
  if ((t === 'chat' || t === 'dash') && !me) return openAuth('login');
  ['chat', 'dash'].forEach((id) => $('#' + id).classList.toggle('hidden', id !== t)); _st(t);
  if (t === 'dash') loadDash().catch((e) => toast(e.message)); if (t === 'chat' && !keep) loadChats().catch((e) => toast(e.message));
};
// ---- dashboard
async function loadDash() {
  const d = await api('/api/dash'), st = (n, l) => `<div class="stat"><b>${num(n)}</b><span>${l}</span></div>`;
  const ul = (a, b, l) => a.length ? a.map((u) => `<div class="prow">${av(u)}<span>${esc(u.name)}</span><button class="btn ghost sm" data-s="${b}" data-u="${u.id}">${l}</button></div>`).join('') : '<div class="empty">Nobody yet.</div>';
  $('#dash').innerHTML = `<div class="card prof">${av(d.me, 'lg')}<div><h2>${esc(d.me.name)}</h2><label class="btn ghost sm">Change photo<input type="file" id="avIn" accept="image/*" hidden></label></div></div>
    <div class="stats">${st(d.stories, 'Stories')}${st(d.views, 'Views')}${st(d.reactions, 'Reactions')}${st(d.comments, 'Comments')}${st(d.followers, 'Followers')}${st(d.following.length, 'Following')}${st(d.reshares, 'Reshares')}</div>
    <h3>My stories</h3>${d.posts.map(postHTML).join('') || '<div class="empty">You have not shared a story yet.</div>'}
    <h3>My saved list</h3>${d.saved.map(postHTML).join('') || '<div class="empty">Tap 🔖 Save on a story to keep it here.</div>'}
    <h3>Following</h3>${ul(d.following, 'funf', 'Unfollow')}<h3>Muted</h3>${ul(d.muted, 'unmute', 'Unmute')}<h3>Blocked</h3>${ul(d.blocked, 'unblock', 'Unblock')}
    <p class="note"><a href="/guidelines.html">Community Guidelines</a> · <a href="/terms.html">Terms &amp; Privacy</a></p>`;
}
// ---- chat
async function loadChats() {
  thr = null; const d = await api('/api/dm');
  $('#chat').innerHTML = '<h3>Messages</h3>' + (d.items.map((u) => `<button class="prow" data-s="dm" data-u="${u.id}">${av(u)}<span><b>${esc(u.name)}</b>${u.unread ? ` <em class="bdg">${u.unread}</em>` : ''}<br><small>${esc(u.last)}</small></span></button>`).join('') || '<div class="empty">No chats yet. Tap ✉ Message on a story to start one.</div>');
}
async function openThread(id) {
  if (!me) return openAuth('login'); const draft = ($('#dmTxt') || {}).value || ''; thr = id; keep = true; showTab('chat'); keep = false;
  const d = await api('/api/dm/' + id);
  const msg = d.msgs.map((m) => `<div class="msg ${m.mine ? 'me' : ''}">${m.media ? (m.mtype === 'image' ? `<img src="/api/media/${m.media}" alt="">` : m.mtype === 'video' ? `<video src="/api/media/${m.media}" controls playsinline></video>` : `<audio src="/api/media/${m.media}" controls></audio>`) : ''}${m.text ? `<p>${esc(m.text)}</p>` : ''}<small>${ago(m.at)}</small></div>`).join('');
  $('#chat').innerHTML = `<div class="chead"><button class="link" data-s="back">← Back</button>${av(d.peer)}<b>${esc(d.peer.name)}</b><small>${d.peer.on ? 'Online' : 'Offline'}</small></div><div class="msgs" id="msgs">${msg || '<div class="empty">Say hello 👋</div>'}</div>` +
    (d.blocked ? '<div class="note">You can’t message this person.</div>' : `<form class="row cform" id="dmForm"><label class="btn ghost sm" title="Camera">📷<input type="file" id="dmCam" accept="image/*,video/*" capture hidden></label><label class="btn ghost sm" title="Photo or video">🖼<input type="file" id="dmFile" accept="image/*,video/*" hidden></label><button type="button" class="btn ghost sm" id="dmRec" title="Voice message">🎤</button><input id="dmTxt" maxlength="1000" placeholder="Message…" autocomplete="off"><button class="btn sm">Send</button></form>`);
  const t = $('#dmTxt'); if (t) t.value = draft; const mb = $('#msgs'); mb.scrollTop = mb.scrollHeight;
}
let rec;
async function recToggle(btn) {
  if (rec) return rec.stop();
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true }), ch = []; rec = new MediaRecorder(s);
    rec.ondataavailable = (e) => ch.push(e.data);
    rec.onstop = async () => { s.getTracks().forEach((t) => t.stop()); btn.textContent = '🎤'; const bl = new Blob(ch, { type: rec.mimeType.split(';')[0] }); rec = null;
      try { await post('/api/dm/' + thr, { media: await up(bl) }); openThread(thr); } catch (e) { toast(e.message); } };
    rec.start(); btn.textContent = '⏹'; toast('Recording… tap again to send');
  } catch { toast('Allow microphone access to send voice messages.'); }
}
async function sendFile(f) { if (!f) return; try { toast('Sending…'); await post('/api/dm/' + thr, { media: await up(f) }); openThread(thr); } catch (e) { toast(e.message); } }
document.addEventListener('submit', async (e) => {
  if (e.target.id !== 'dmForm') return; e.preventDefault(); const t = $('#dmTxt'); if (!t.value.trim()) return;
  try { await post('/api/dm/' + thr, { text: t.value }); t.value = ''; openThread(thr); } catch (x) { toast(x.message); }
});
document.addEventListener('change', async (e) => {
  const i = e.target; if (i.id === 'dmCam' || i.id === 'dmFile') sendFile(i.files[0]);
  if (i.id === 'avIn' && i.files[0]) { try { await up(i.files[0], true); toast('Photo updated.'); loadDash(); } catch (x) { toast(x.message); } }
});
// ---- actions
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-s]'); if (!b) return; const s = b.dataset.s, card = b.closest('.card'), id = card && card.dataset.id, u = b.dataset.u;
  try {
    if (s === 'share') { const link = location.origin + '/#' + id; if (navigator.share) return navigator.share({ title: 'WhyIQuit', text: 'A story on WhyIQuit', url: link }).catch(() => {}); await navigator.clipboard.writeText(link); return toast('Link copied.'); }
    if (s === 'back') return loadChats(); if (s === 'rec') return;
    if (!me) return openAuth('login');
    if (b.id === 'dmRec') return recToggle(b);
    if (s === 'save') { const d = await post('/api/save/' + id); b.textContent = d.on ? '🔖 Saved' : '🔖 Save'; toast(d.on ? 'Added to your list.' : 'Removed from your list.'); }
    else if (s === 'reshare') { if (!confirm('Reshare this story on your profile?')) return; await post('/api/reshare/' + id); toast('Reshared!'); loadPosts(); }
    else if (s === 'follow' || s === 'funf') { const d = await post('/api/follow/' + u); document.querySelectorAll(`[data-s=follow][data-u="${u}"]`).forEach((x) => { x.textContent = d.on ? 'Unfollow' : 'Follow'; }); toast(d.on ? 'Following.' : 'Unfollowed.'); if (s === 'funf') loadDash(); }
    else if (['mute', 'block', 'unmute', 'unblock'].includes(s)) {
      const un = s.startsWith('un'), k = s.replace('un', ''); if (!un && !confirm(k === 'block' ? 'Block this person? You will not see each other’s stories or messages.' : 'Mute this person’s stories?')) return;
      await post(`/api/${k}/${u}`); toast(un ? 'Done.' : k === 'block' ? 'Blocked.' : 'Muted.'); if (un) loadDash(); else loadPosts();
    } else if (s === 'dm') openThread(u);
  } catch (err) { toast(err.message); }
});
// ---- live chat + online presence (reconnects after sign-in so you show as online)
let es, had = false;
function openES() {
  if (!('EventSource' in window)) return; if (es) es.close(); es = new EventSource('/api/stream');
  es.onmessage = (m) => { let ev; try { ev = JSON.parse(m.data); } catch { return; }
    if (ev.t === 'dm' && me && ev.to === me.id) { if (thr === ev.from && !$('#chat').classList.contains('hidden')) openThread(thr); else toast('New message ✉'); } };
}
setInterval(() => { if (!!me !== had) { had = !!me; openES(); } }, 2000);
setTimeout(() => { const id = location.hash.slice(1), c = id && document.querySelector(`[data-id="${id}"]`); if (c) c.scrollIntoView({ block: 'center' }); }, 1500);
