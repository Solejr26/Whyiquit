// WhyIQuit social layer: follow, block, mute, save, reshare, dashboard, direct chat with photo/video/voice.
'use strict';
const fs = require('fs'), path = require('path');
const ftyp = (b) => ['ftyp', 'moov'].includes(b.slice(4, 8).toString());
const T = { 'image/jpeg': ['jpg', (b) => b[0] === 255 && b[1] === 216], 'image/png': ['png', (b) => b[1] === 80 && b[2] === 78],
  'image/webp': ['webp', (b) => b.slice(8, 12).toString() === 'WEBP'], 'video/mp4': ['mp4', ftyp], 'video/quicktime': ['mov', ftyp],
  'video/webm': ['webm', (b) => b[0] === 26 && b[1] === 69], 'audio/webm': ['weba', (b) => b[0] === 26 && b[1] === 69],
  'audio/ogg': ['ogg', (b) => b.slice(0, 4).toString() === 'OggS'], 'audio/mp4': ['m4a', ftyp] };
const tog = (a, x) => { const i = a.indexOf(x); if (i < 0) { a.push(x); return true; } a.splice(i, 1); return false; };

module.exports = async (c) => {
  const { req, res, url, p, m, me, db, uidx, send, fail, limit, body, need, uid, save, broadcast, postView, hdr, dir, isOn } = c;
  let x; const R = (meth, re) => (m === meth ? p.match(re) : null);
  const readBuf = (max) => new Promise((ok, no) => { let n = 0; const a = [];
    req.on('data', (d) => { n += d.length; if (n > max) { no(new c.HttpError(413, 'File too large')); req.destroy(); } else a.push(d); });
    req.on('end', () => ok(Buffer.concat(a))); req.on('error', no); });
  const brief = (id) => { const u = uidx.get(id); return { id, name: u.name, av: u.av || null, on: isOn(id) }; };

  if ((x = R('GET', /^\/api\/media\/([\w-]+)$/))) {      // photos, videos, voice notes, avatars (private unless avatar)
    const id = x[1], f = db.media[id]; if (!f) fail(404, 'Not found');
    if (!f.pub && !(me && (f.owner === me.id || db.msgs.some((q) => q.media === id && (q.from === me.id || q.to === me.id))))) fail(404, 'Not found');
    const fp = path.join(dir, 'uploads', id + '.' + T[f.type][0]); let st; try { st = fs.statSync(fp); } catch { fail(404, 'Not found'); }
    let s = 0, e = st.size - 1; const r = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
    if (r) { s = r[1] ? +r[1] : 0; e = r[2] ? Math.min(+r[2], e) : e; } if (s > e) fail(416, 'Bad range');
    res.writeHead(r ? 206 : 200, { ...hdr(), 'Content-Type': f.type, 'Accept-Ranges': 'bytes', 'Content-Length': e - s + 1, 'Cache-Control': 'private, max-age=3600',
      ...(r ? { 'Content-Range': `bytes ${s}-${e}/${st.size}` } : {}) });
    fs.createReadStream(fp, { start: s, end: e }).pipe(res); return true;
  }
  if (R('POST', /^\/api\/upload$/)) {
    need(); limit('up:' + me.id, 30, 36e5, 'Upload limit reached. Try again later.');
    const t = String(req.headers['content-type'] || '').split(';')[0].trim(), ty = T[t]; if (!ty) fail(415, 'Unsupported file type');
    const av = url.searchParams.get('avatar') === '1'; if (av && !t.startsWith('image/')) fail(400, 'Please pick a picture.');
    const b = await readBuf(t.startsWith('image/') ? 6e6 : 25e6); if (!b.length || !ty[1](b)) fail(400, 'That file looks invalid.');
    const id = uid(); fs.mkdirSync(path.join(dir, 'uploads'), { recursive: true }); fs.writeFileSync(path.join(dir, 'uploads', id + '.' + ty[0]), b, { mode: 0o600 });
    db.media[id] = { owner: me.id, type: t, pub: av }; if (av) me.av = id; save(); send(res, 200, { id, type: t }); return true;
  }
  if ((x = R('POST', /^\/api\/(follow|block|mute)\/([\w-]+)$/))) {
    need(); limit('sc:' + me.id, 60, 6e4); const k = { follow: 'fol', block: 'blk', mute: 'mut' }[x[1]];
    if (x[2] === me.id || !uidx.has(x[2])) fail(400, 'Not allowed');
    me[k] = me[k] || []; const on = tog(me[k], x[2]); if (x[1] === 'block' && on) me.fol = (me.fol || []).filter((i) => i !== x[2]);
    save(); send(res, 200, { on }); return true;
  }
  if ((x = R('POST', /^\/api\/save\/([\w-]+)$/))) { need(); me.marks = me.marks || []; const on = tog(me.marks, x[1]); save(); send(res, 200, { on }); return true; }
  if ((x = R('POST', /^\/api\/reshare\/([\w-]+)$/))) {
    need(); limit('rsh:' + me.id, 10, 36e5, 'Slow down a little.');
    const o = db.posts.find((q) => q.id === x[1] && q.status === 'live'); if (!o) fail(404, 'Not found');
    const a = !o.anonymous && o.userId && uidx.get(o.userId);
    const n = { ...o, id: uid(), userId: me.id, anonymous: false, rx: {}, views: 0, commentCount: 0, reporters: [], createdAt: Date.now(), via: a ? a.name : 'Anonymous', shares: 0 };
    o.shares = (o.shares || 0) + 1; db.posts.push(n); save(); broadcast({ t: 'post', id: n.id }); send(res, 201, { ok: true }); return true;
  }

  // ---- direct chat
  const peer = (id) => { const u = uidx.get(id); if (!u || u.banned || id === me.id) fail(404, 'Not found'); return u; };
  const blocked = (u) => (me.blk || []).includes(u.id) || (u.blk || []).includes(me.id);
  if (R('GET', /^\/api\/dm$/)) {
    need(); const s = new Map();
    for (const q of db.msgs) { if (q.from !== me.id && q.to !== me.id) continue; const o = q.from === me.id ? q.to : q.from; const e = s.get(o) || { n: 0 }; e.last = q; if (q.to === me.id && !q.read) e.n++; s.set(o, e); }
    send(res, 200, { items: [...s].filter(([o]) => uidx.has(o) && !(me.blk || []).includes(o)).sort((a, b) => b[1].last.at - a[1].last.at)
      .map(([o, e]) => ({ ...brief(o), unread: e.n, last: e.last.text || (e.last.mtype === 'audio' ? '🎤 Voice message' : '📎 Attachment') })) }); return true;
  }
  if ((x = R('GET', /^\/api\/dm\/([\w-]+)$/))) {
    need(); const u = peer(x[1]); let ch = false;
    const l = db.msgs.filter((q) => (q.from === me.id && q.to === u.id) || (q.from === u.id && q.to === me.id));
    l.forEach((q) => { if (q.to === me.id && !q.read) { q.read = true; ch = true; } }); if (ch) save();
    send(res, 200, { peer: brief(u.id), blocked: blocked(u), msgs: l.slice(-100).map((q) => ({ id: q.id, mine: q.from === me.id, text: q.text, media: q.media, mtype: q.mtype, at: q.at })) }); return true;
  }
  if ((x = R('POST', /^\/api\/dm\/([\w-]+)$/))) {
    need(); limit('dm:' + me.id, 40, 6e4, 'You are sending too fast.'); const u = peer(x[1]); if (blocked(u)) fail(403, 'You cannot message this person.');
    const b = await body(req), text = c.cleanBlock(b.text, 1000), f = b.media && db.media[b.media];
    if (b.media && !(f && f.owner === me.id)) fail(400, 'Bad attachment'); if (!text && !f) fail(400, 'Write something first.');
    const q = { id: uid(), from: me.id, to: u.id, text, at: Date.now(), read: false }; if (f) { q.media = b.media; q.mtype = f.type.split('/')[0]; }
    db.msgs.push(q); if (db.msgs.length > 20000) db.msgs.splice(0, 2000); save(); broadcast({ t: 'dm', to: u.id, from: me.id }); send(res, 201, { ok: true }); return true;
  }

  // ---- dashboard
  if (R('GET', /^\/api\/dash$/)) {
    need(); const mine = db.posts.filter((q) => q.userId === me.id), sum = (f) => mine.reduce((a, q) => a + f(q), 0), nm = (ids) => (ids || []).filter((i) => uidx.has(i)).map(brief);
    send(res, 200, { me: brief(me.id), followers: db.users.filter((u) => (u.fol || []).includes(me.id)).length, following: nm(me.fol), blocked: nm(me.blk), muted: nm(me.mut),
      stories: mine.length, views: sum((q) => q.views || 0), reactions: sum((q) => Object.values(q.rx || {}).reduce((a, b) => a + b, 0)), comments: sum((q) => q.commentCount || 0), reshares: sum((q) => q.shares || 0),
      posts: mine.sort((a, b) => b.createdAt - a.createdAt).slice(0, 30).map((q) => postView(q, me)),
      saved: (me.marks || []).map((i) => db.posts.find((q) => q.id === i && q.status === 'live')).filter(Boolean).slice(-30).map((q) => postView(q, me)) }); return true;
  }
  return false;
};
