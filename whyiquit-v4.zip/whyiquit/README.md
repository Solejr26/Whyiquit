# WhyIQuit v2

A fun place to share the real reasons people quit their jobs. Zero npm dependencies, just Node 18+.

## Features
Accounts (email or phone + confirmation code), forgot-password, live emoji reactions, views and comments, network-quality
indicator, green/white theme with dark mode, AI-assisted community guidelines and moderation, admin panel with an AI assistant.

## Run locally
```
node server.js        # http://localhost:3000
node smoke-test.js    # automated checks
```
In development the confirmation code and a one-time admin login are printed in the terminal.
Admin panel: `/admin.html`.

## Settings (environment variables)
| Name | Purpose |
|---|---|
| `NODE_ENV=production` | Required online. Secure cookies, HSTS, no sample data, no dev codes. |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Creates your admin account on first start (password 10+ chars, letters + numbers). |
| `APP_URL` | Your public https address. |
| `DATA_DIR` | Folder on a persistent disk for `data.json`. |
| `TRUST_PROXY_HOPS` | Proxies in front of the app (1 on Render/Railway/Fly). |
| `RESEND_API_KEY`, `MAIL_FROM` | Sends email confirmation codes (resend.com). |
| `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM` | Sends SMS confirmation codes. |
| `ANTHROPIC_API_KEY`, `AI_MODEL` | Turns on AI moderation of new stories/comments and the admin AI assistant. |

Without an email/SMS provider nobody can confirm an account in production.

## Deploy
Render: push to GitHub, New > Blueprint (uses `render.yaml`, needs a paid instance for the disk), fill in the env vars.
Any Docker host: use the `Dockerfile`, mount a volume at `/data`. Always serve over HTTPS.

## Security built in
- Passwords hashed with scrypt (never stored); login throttled per IP and per account; constant-time checks.
- Sessions: random token, only its hash stored; HttpOnly, SameSite=Strict, Secure cookie; admin sessions last 8 hours.
- CSRF: custom header + Origin check on every write. Strict Content-Security-Policy (no inline scripts), HSTS, no framing.
- Rate limits on every sensitive action; request size/time limits; strict input validation; output escaped.
- AI output can only advise or hold content for review; admins click the buttons. Untrusted text is fenced from AI instructions.
- Account-enumeration safe sign-up/reset replies; banned users are signed out immediately.

No system is unhackable. Keep Node updated, use strong unique admin credentials, back up `data.json` (a `.bak` is made at each start),
and consider a penetration test before large-scale launch. Next steps for growth: move from `data.json` to Postgres, add admin 2FA,
add Cloudflare in front for DDoS protection.
