// Starts the server on a temp dir and exercises the main flows. Run: node smoke-test.js
const { spawn } = require('child_process'); const fs = require('fs'), os = require('os'), path = require('path');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wiq-')); const port = 4100 + Math.floor(Math.random() * 500);
const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT: port, DATA_DIR: dir, NODE_ENV: 'development' } });
let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
const B = `http://localhost:${port}`; let pass = 0, failN = 0;
const ok = (c, m) => { c ? pass++ : failN++; console.log((c ? 'PASS ' : 'FAIL ') + m); };
async function call(p, { body, cookie, method, origin } = {}) {
  const h = { 'X-Requested-With': 'fetch' }; if (cookie) h.Cookie = cookie; if (origin) h.Origin = origin; if (body) h['Content-Type'] = 'application/json';
  const r = await fetch(B + p, { method: method || (body ? 'POST' : 'GET'), headers: h, body: body && JSON.stringify(body) });
  const sc = r.headers.get('set-cookie'); return { s: r.status, d: await r.json().catch(() => ({})), cookie: sc && sc.split(';')[0], h: r.headers };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  await sleep(900);
  const h = await call('/healthz'); ok(h.s === 200, 'health');
  ok(/frame-ancestors 'none'/.test(h.h.get('content-security-policy')), 'CSP header present');
  ok((await call('/api/posts', { body: { story: 'x'.repeat(30) } })).s === 401, 'posting requires login');
  ok((await fetch(B + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status === 403, 'CSRF header required');
  ok((await call('/api/auth/login', { body: { identifier: 'a@b.co', password: 'x' }, origin: 'https://evil.example' })).s === 403, 'foreign Origin blocked');
  ok((await fetch(B + '/../server.js')).status === 404, 'no path traversal');
  const rg = await call('/api/auth/register', { body: { name: 'tester', identifier: 'tester@example.com', password: 'Passw0rd!xx', agree: true } });
  ok(rg.s === 200 && rg.d.devCode, 'register returns dev code');
  ok((await call('/api/auth/login', { body: { identifier: 'tester@example.com', password: 'Passw0rd!xx' } })).d.needVerify === true, 'unverified login asks for code');
  ok((await call('/api/auth/verify', { body: { identifier: 'tester@example.com', code: '000000' } })).s === 400, 'wrong code rejected');
  const rg2 = await call('/api/auth/register', { body: { name: 'tester2', identifier: 'weak@example.com', password: 'abc', agree: true } }); ok(rg2.s === 400, 'weak password rejected');
  const vf = await call('/api/auth/verify', { body: { identifier: 'tester@example.com', code: rg.d.devCode } }); ok(vf.s === 200 && vf.cookie, 'verify logs in');
  const ck = vf.cookie;
  const post = await call('/api/posts', { cookie: ck, body: { story: 'My manager changed my goals every single week without telling anyone.', reason: 'Toxic boss', anonymous: true } });
  ok(post.s === 201 && post.d.post.author === null, 'post created anonymously'); const id = post.d.post.id;
  const link = await call('/api/posts', { cookie: ck, body: { story: 'Visit www.spam-site.com for amazing deals right now please!!', reason: 'Other' } }); ok(link.d.post && link.d.post.pending, 'link post held for review');
  const rx = await call(`/api/posts/${id}/react`, { cookie: ck, body: { emoji: '❤️' } }); ok(rx.d.rx['❤️'] === 1, 'reaction counted');
  ok((await call(`/api/posts/${id}/react`, { cookie: ck, body: { emoji: '💩' } })).s === 400, 'unknown emoji rejected');
  ok((await call(`/api/posts/${id}/comments`, { cookie: ck, body: { text: 'Same here.' } })).s === 201, 'comment created');
  ok((await call(`/api/posts/${id}/comments`)).d.comments.length === 1, 'comment listed');
  // SSE
  const ctl = new AbortController(); const sse = await fetch(B + '/api/stream', { signal: ctl.signal }); const rd = sse.body.getReader(); let got = '';
  await sleep(200); await call(`/api/posts/${id}/react`, { cookie: ck, body: { emoji: '😂' } });
  const t = Date.now(); while (Date.now() - t < 2000 && !got.includes('"t":"rx"')) { const { value } = await Promise.race([rd.read(), sleep(500).then(() => ({}))]); if (value) got += Buffer.from(value).toString(); }
  ctl.abort(); ok(got.includes('"t":"rx"'), 'live reaction event received over SSE');
  ok((await call('/api/admin/overview', { cookie: ck })).s === 404, 'non-admin cannot reach admin API');
  // admin
  const m = log.match(/Admin login: (\S+) \/ (\S+)/); const ad = await call('/api/auth/login', { body: { identifier: m[1], password: m[2] } }); ok(ad.d.me && ad.d.me.role === 'admin', 'admin login');
  const q = await call('/api/admin/posts?filter=pending', { cookie: ad.cookie }); ok(q.d.items.length === 1, 'admin sees held post');
  ok((await call(`/api/admin/posts/${q.d.items[0].id}/approve`, { cookie: ad.cookie, body: {} })).s === 200, 'admin approves');
  const ai = await call('/api/admin/ai', { cookie: ad.cookie, body: { message: 'summary' } }); ok(ai.s === 200 && ai.d.reply, 'AI assistant endpoint (fallback without key)');
  for (let i = 0; i < 7; i++) await call('/api/auth/login', { body: { identifier: 'nobody@example.com', password: 'x' } });
  ok((await call('/api/auth/login', { body: { identifier: 'nobody@example.com', password: 'x' } })).s === 429, 'login brute-force throttled');
  console.log(`\n${pass} passed, ${failN} failed`); srv.kill(); process.exit(failN ? 1 : 0);
})().catch((e) => { console.error(e); srv.kill(); process.exit(1); });
